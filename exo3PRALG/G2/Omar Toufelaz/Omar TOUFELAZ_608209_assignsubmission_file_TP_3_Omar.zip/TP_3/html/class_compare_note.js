var class_compare_note =
[
    [ "CompareNote", "class_compare_note.html#add2ebb37961e3f904a669c29e94c2327", null ],
    [ "operator()", "class_compare_note.html#a2e2bff69feeec5ad8dc04fd34e889895", null ]
];