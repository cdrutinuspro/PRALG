var searchData=
[
  ['getnom_0',['GetNom',['../class_eleve.html#ac350cce0072485d7424675914851b415',1,'Eleve']]],
  ['getnote_1',['GetNote',['../class_eleve.html#a7505567591d82246f9fe8c0281fd81a3',1,'Eleve']]]
];
