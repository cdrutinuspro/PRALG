var class_eleve =
[
    [ "Eleve", "class_eleve.html#ab58cf14e10d99f2d451cafbfecc43687", null ],
    [ "GetNom", "class_eleve.html#ac350cce0072485d7424675914851b415", null ],
    [ "GetNote", "class_eleve.html#a7505567591d82246f9fe8c0281fd81a3", null ],
    [ "SetNote", "class_eleve.html#a03b259b0cb457c1ab43e52730af8ebdc", null ]
];