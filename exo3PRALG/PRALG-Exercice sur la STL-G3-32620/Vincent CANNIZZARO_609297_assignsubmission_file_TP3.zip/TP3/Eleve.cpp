#include "Eleve.h"

void Eleve::print() {
    std::cout<<name<<", note : " << note<<std::endl;

}
