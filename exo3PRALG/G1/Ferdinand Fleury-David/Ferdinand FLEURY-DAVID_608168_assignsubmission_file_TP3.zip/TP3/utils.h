#pragma once
#include <string>
#include <vector>
#include "eleve.h"

using namespace std;


string nomAleatoire();
vector<Eleve> genererEleves(int n);
